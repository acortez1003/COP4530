#include <iostream>
#include <string>
#include <cctype>
#include <unordered_map>    // hashtable
#include <vector>
#include <algorithm>        // std::partial_sort
#include <ctime>

void countFrequencies();

int main()
{
    std::clock_t time1, time2;
    time1 = std::clock();
    countFrequencies();
    time2 = std::clock();
    double duration = static_cast<double> (time2 - time1) / CLOCKS_PER_SEC;
    std::cout << "\nTime: " << duration << " seconds.\n";
    return 0;
}

void countFrequencies()
{
    std::unordered_map<char, int> charFreq;
    std::unordered_map<std::string, int> wordFreq;
    std::unordered_map<std::string, int> numFreq;
    char ch;
    std::string wordStr, numStr;
    int charSize = 0, wordSize = 0, numSize = 0; 

    // putting values into their respective hashtable
    while(std::cin.get(ch))             // reading standard input
    {
        
        charFreq[ch]++;
        if(std::isalpha(ch))
        {
            wordStr += std::tolower(ch);
        }
        else    // hit non-alpha
        {
            if(!wordStr.empty())    // word is complete
            {
                wordFreq[wordStr]++;
                wordStr.clear();
            }
        }

        if(std::isdigit(ch))
            numStr += ch;
        else    // hit non-digit
        {
            if(!numStr.empty())
            {
                numFreq[numStr]++;
                numStr.clear();
            }
        }
    }

    // creating each vector
    std::vector<std::pair<char, int>> charVec(charFreq.begin(), charFreq.end());
    std::vector<std::pair<std::string, int>> wordVec(wordFreq.begin(), wordFreq.end());
    std::vector<std::pair<std::string, int>> numVec(numFreq.begin(), numFreq.end());

    // sorting each hashtable + tie-breakers
    std::sort(charVec.begin(), charVec.end(), [](const auto &a, const auto &b) 
    {
        if(a.second == b.second)
            return int(a.first) < int(b.first); // highest ASCII value first
        return a.second > b.second;
    });
    std::sort(wordVec.begin(), wordVec.end(), [](const auto &a, const auto &b) 
    {
        if(a.second == b.second)
            return a.first < b.first;
        return a.second > b.second;             // occurred first
    });
    std::sort(numVec.begin(), numVec.end(), [](const auto &a, const auto &b) 
    {
        if(a.second == b.second)
            return a.first < b.first;           // occurred first
        return a.second > b.second;
    });

    charSize = charVec.size();                  // saving total size
    wordSize = wordVec.size();
    numSize = numVec.size();

    // only show top 10
    if(charVec.size() > 10) charVec.resize(10);
    if(wordVec.size() > 10) wordVec.resize(10);
    if(numVec.size() > 10) numVec.resize(10);

    // printing "Top Ten"
    int i = 0, j = 0, k = 0;
    std::cout << "\nTotal of " << charSize << " characters, " << charVec.size() << " most used characters:\n";
    for(const auto &pair : charVec)
    {
        if(pair.first == '\n')
            std::cout << "No. "<< i << ": \\n\t\t" << pair.second << '\n';
        else
            std::cout << "No. " << i << ": " << pair.first << "\t\t" << pair.second << '\n';
        i++;
    }

    std::cout << "\nTotal of " << wordSize << " words, " << wordVec.size() << " most used words:\n";
    for(const auto &pair : wordVec)
    {
        std::cout << "No. " << j << ": " << pair.first << "\t\t\t" << pair.second << '\n';
        j++;
    }

    std::cout << "\nTotal of " << numSize << " numbers, " << numVec.size() << " most used numbers:\n";
    for(const auto &pair : numVec)
    {
        std::cout << "No. " << k << ": " << pair.first << "\t\t" << pair.second << '\n';
        k++;
    }
}